/**
 * This class represents a player's hand in a card game.
 * It contains a list of cards and methods to add cards to the hand,
 * get the total value of the hand for the game "Blackjack",
 * get the size of the hand, and clear the hand.
*/

import java.util.ArrayList;
import java.util.List;

public class Hand {
    private List<Card> cards;
    private int totalValue;
    

    public Hand() {
        cards = new ArrayList<Card>();
        totalValue = 0;
    }
    
    /*
     * Adds a card to the hand and updates the total value of the hand.
     * 
     * @param card the card to add to the hand
     */
    public void addCard(Card card) {
        cards.add(card);
        totalValue += card.getValue();
    }
    
    /*
     * Returns a list of cards in the hand.
     * @return the list of cards in the hand
     */
    public List<Card> getCards() {
        return cards;
    }
    
    /*
     * Calculates and returns the total value of the hand for the game "Blackjack".
     * Aces are counted as 11, unless doing so would cause the hand to bust (total value > 21).
     * In that case, aces are counted as 1.
     * 
     * @return the total value of the hand for the game "Blackjack"
     */
    public int getBlackjackValue() {
        int value = 0;
        boolean hasAce = false;

        for (Card card : cards) {
            if (card.getValue() == 1) { // Ace
                hasAce = true;
                value += 11;
            } else if (card.getValue() >= 10) { // Face card
                value += 10;
            } else {
                value += card.getValue();
            }
        }

        if (hasAce && value > 21) {
            value -= 10;
        }

        return value;
    }

    /*
     * Returns the number of cards in the hand.
     * 
     * @return the number of cards in the hand
     */
    public int size() {
        return cards.size();
    }

    /*
     * Clears the hand by removing all cards and resetting the total value to 0.
     */
    public void clear() {
        cards.clear();
        totalValue = 0;
    }
}