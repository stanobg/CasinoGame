/**
 * 
 * This class is responsible for creating and managing the game logic and GUI of the Casino War game
 * 
 * It extends JPanel
 */

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class CasinoWar extends JPanel {
    private static final int INITIAL_BALANCE = 1000;
    private static final int MIN_BET = 1;
    private static final int MAX_BET = 200;
    private static final int TIE_PAYOUT = 1;

    private Deck deck;
    private int balance;
    private JButton dealButton;
    private JButton continueButton;
    private JTextField betField;
    private JLabel playerCardLabel;
    private JLabel dealerCardLabel;
    private JLabel balanceLabel;
    private JLabel playerLabel;
    private JLabel dealerLabel;
    private JLabel messageLabel;

    /**
     * Empty constructor for Casino War
     */
    public CasinoWar() {
        deck = new Deck(CardImages.CARD_IMAGES);
        balance = INITIAL_BALANCE;

        setLayout(new BorderLayout());

        JPanel topPanel = new JPanel(new FlowLayout());
        balanceLabel = new JLabel("Balance: $" + balance);
        topPanel.add(balanceLabel);
        add(topPanel, BorderLayout.NORTH);

        JPanel centerPanel = new JPanel(new GridLayout(1, 2));
        playerCardLabel = new JLabel();
        dealerCardLabel = new JLabel();
        playerLabel = new JLabel("Player:");
        dealerLabel = new JLabel("Dealer:");
        playerCardLabel.setPreferredSize(new Dimension(100, 200));
        dealerCardLabel.setPreferredSize(new Dimension(200, 200));
        centerPanel.add(playerLabel);
        centerPanel.add(playerCardLabel);
        centerPanel.add(dealerLabel);
        centerPanel.add(dealerCardLabel);
        add(centerPanel, BorderLayout.CENTER);

        JPanel bottomPanel = new JPanel(new FlowLayout());
        
     // Adding the components for the bottom panel
        JLabel betLabel = new JLabel("Bet:");
        bottomPanel.add(betLabel);

        betField = new JTextField(5);
        bottomPanel.add(betField);

        dealButton = new JButton("Deal");
        dealButton.addActionListener(new DealButtonListener());
        bottomPanel.add(dealButton);

        continueButton = new JButton("Continue");
        continueButton.addActionListener(new ContinueButtonListener());
        continueButton.setEnabled(false);
        bottomPanel.add(continueButton);

        messageLabel = new JLabel("Place your bet and click Deal to start playing.");
        bottomPanel.add(messageLabel);

        add(bottomPanel, BorderLayout.SOUTH);
    }

    /**
     * Method that deals the cards, shows the images of the cards,
     * and edits the balance based on the result of the game
     */
    private void deal() {
    	  int bet = Integer.parseInt(betField.getText());
          if (bet < MIN_BET || bet > MAX_BET) {
              JOptionPane.showMessageDialog(this, "Invalid bet amount.", "Error", JOptionPane.ERROR_MESSAGE);
              return;
          }
          if (bet > balance) {
              JOptionPane.showMessageDialog(this, "Not enough balance.", "Error", JOptionPane.ERROR_MESSAGE);
              return;
          }

          deck.shuffle();
          Card playerCard = deck.drawCard();
          Card dealerCard = deck.drawCard();

          playerCardLabel.setIcon(new ImageIcon(playerCard.getImage().getScaledInstance(100, 200, Image.SCALE_SMOOTH)));
          dealerCardLabel.setIcon(new ImageIcon(dealerCard.getImage().getScaledInstance(100, 200, Image.SCALE_SMOOTH)));
          
          
          JLabel playerCardText = new JLabel(new ImageIcon(playerCard.getImage()));
          JLabel dealerCardText = new JLabel(new ImageIcon(dealerCard.getImage()));
          messageLabel.setText("");
          messageLabel.add(playerCardText);
          messageLabel.add(dealerCardText);
          
          int result = playerCard.compareTo(dealerCard);
          if (playerCard.getValue() > dealerCard.getValue()) {
              balance += bet + bet;
              messageLabel.setText("You win! You get $" + (bet + bet) + ".");
              
          } else if (playerCard.getValue() < dealerCard.getValue()) {
              messageLabel.setText("You lose! You lose $" + bet + ".");
              balance -= bet;
          } else {
              balance += bet * TIE_PAYOUT;
              messageLabel.setText("It's a tie! Your bet of $" + bet + " is returned to you.");
          }

          balanceLabel.setText("Balance: $" + balance);

          if (balance <= 0) {
              JOptionPane.showMessageDialog(this, "Game over. You have no more balance.", "Game Over",
                      JOptionPane.INFORMATION_MESSAGE);
              System.exit(0);
          } else {
              continueButton.setEnabled(true);
              dealButton.setEnabled(false);
          }
    }

    private class DealButtonListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            deal();
        }
    }

    private class ContinueButtonListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            deck = new Deck(CardImages.CARD_IMAGES);
            betField.setText("100");
            playerCardLabel.setIcon(null);
            dealerCardLabel.setIcon(null);
            dealButton.setEnabled(true);
            continueButton.setEnabled(false);
            messageLabel.setText("Place your bet and click Deal to start playing.");
        }
    }

}