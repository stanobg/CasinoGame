import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

public class MainMenuGUI extends JFrame implements ActionListener {

    private JFrame frame;
    private JButton button1, button2, button3, exitButton;
    private JLabel balanceLabel;
    private int balance; // new Balance object
    
    public MainMenuGUI() {
    	balance = 1000;
    	frame = new JFrame("Main Menu");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel();
        panel.setBackground(new Color(38, 50, 56)); // set background color
        panel.setPreferredSize(new Dimension(400, 300));
        
        button1 = new JButton("Roulette");
        button1.setBackground(new Color(229, 57, 53)); // set button color
        button1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                RouletteGame game = new RouletteGame(balance); // pass the balance object to the game
                JFrame gameFrame = new JFrame("Roulette"); // create a new JFrame for the game
                gameFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

                gameFrame.add(game); // add the game panel to the JFrame
                gameFrame.pack();
                gameFrame.setVisible(true); // display the JFrame
            }
        });

        button2 = new JButton("Casino War");
        button2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                CasinoWar game = new CasinoWar(); // pass the balance object to the game
                JFrame gameFrame = new JFrame("Casino War"); // create a new JFrame for the game
                gameFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

                gameFrame.add(game); // add the game panel to the JFrame
                gameFrame.pack();
                gameFrame.setVisible(true); // display the JFrame
            }
        });



        button3 = new JButton("Blackjack");
        button3.setBackground(new Color(211, 47, 47)); // set button color
        button3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Blackjack game = new Blackjack(); // pass the balance object to the game
                JFrame gameFrame = new JFrame("Blackjack"); // create a new JFrame for the game
                gameFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

                gameFrame.add(game); // add the game panel to the JFrame
                gameFrame.pack();
                gameFrame.setVisible(true); // display the JFrame
            }
        });

        exitButton = new JButton("Exit");
        exitButton.setBackground(new Color(84, 110, 122)); // set button color
        exitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame currentFrame = (JFrame) SwingUtilities.getWindowAncestor(panel);
                currentFrame.dispose(); // dispose of the current JFrame
            }
        });
        
        
        balanceLabel = new JLabel("Balance: $" + balance);
        balanceLabel.setForeground(Color.WHITE);
        panel.add(balanceLabel);

        panel.add(button1);
        panel.add(button2);
        panel.add(button3);
        panel.add(exitButton); 

        JLabel titleLabel = new JLabel("Main Menu");
        titleLabel.setForeground(Color.WHITE); // set text color
        frame.add(titleLabel, BorderLayout.NORTH); // add label to the top
        frame.add(panel, BorderLayout.CENTER);
        frame.getContentPane().setBackground(new Color(33, 33, 33)); // set background color of the frame's content pane
        frame.pack(); // adjust the size of the frame to fit the components
        frame.setLocationRelativeTo(null); // center the frame on the screen
        frame.setVisible(true); // display the frame
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        // TODO Auto-generated method stub
    }
    
    public void updateBalance(int newBalance) {
        balance = newBalance;
        balanceLabel.setText("Balance: $" + balance);
    }

   }
        