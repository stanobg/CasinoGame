/**
 * This class represents a playing card with a suit, rank, and image.
*/

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

public class Card implements Comparable<Card> {
	private int suit;
	private int rank;
	private BufferedImage image;
	public static final int NUM_SUITS = 4;
	public static final int NUM_RANKS = 13;
	public static final String[] SUIT_NAMES = { "clubs", "diamonds", "hearts", "spades" };
	public static final String[] RANK_NAMES = { "ace", "2", "3", "4", "5", "6", "7", "8", "9", "10", "jack", "queen",
			"king" };

	
	/**
	 * Creates a new Card object with the specified suit and rank.
	 * 
	 * @param suit - the suit of the card
	 * @param rank - the rank of the card
	 * @throws IllegalArgumentException if the suit or rank is invalid
	 */
	public Card(int suit, int rank) {
		if (suit < 0 || suit >= NUM_SUITS) {
			throw new IllegalArgumentException("Invalid suit");
		}
		if (rank < 1 || rank > NUM_RANKS) {
			throw new IllegalArgumentException("Invalid rank");
		}
		this.suit = suit;
		this.rank = rank;
		// loads the card image from the specified file path
		String imagePath = "CardImages/" + RANK_NAMES[rank - 1] + "_of_" + SUIT_NAMES[suit] + ".png";
		try {
			image = ImageIO.read(new File(imagePath));
		} catch (IOException e) {
			System.out.println("Error loading card image: " + e.getMessage());
		}
	}

	/**
	 * Gets the suit of the card.
	 * 
	 * @return the suit of the card
	 */
	public int getSuit() {
		return suit;
	}

	/**
	 * Gets the rank of the card.
	 * 
	 * @return the rank of the card
	 */
	public int getRank() {
		return rank;
	}

	/**
	 * Gets the value of the card. The value is determined by the rank, where aces are worth 14.
	 * 
	 * @return the value of the card
	 */
	public int getValue() {
	    int rankValue;
	    switch (RANK_NAMES[rank - 1]) {
	        case "ace":
	            rankValue = 14;
	            break;
	        case "2":
	            rankValue = 2;
	            break;
	        case "3":
	            rankValue = 3;
	            break;
	        case "4":
	            rankValue = 4;
	            break;
	        case "5":
	            rankValue = 5;
	            break;
	        case "6":
	            rankValue = 6;
	            break;
	        case "7":
	            rankValue = 7;
	            break;
	        case "8":
	            rankValue = 8;
	            break;
	        case "9":
	            rankValue = 9;
	            break;
	        case "10":
	            rankValue = 10;
	            break;
	        case "jack":
	            rankValue = 11;
	            break;
	        case "queen":
	            rankValue = 12;
	            break;
	        case "king":
	            rankValue = 13;
	            break;
	        case "0":
	            rankValue = 0;
	            break;
	        default:
	            rankValue = -1; // Error value
	    }
	    return rankValue;
	}

	/**
	 * Returns the image associated with this card.
	 *
	 * @return the image of this card
	 */
	public BufferedImage getImage() {
		return image;
	}

	/**
	 * Compares this card to another card based on their values.
	 * 
	 * @param other the card to compare this card to
	 * @return a negative integer, zero, or a positive integer as this card is less than, equal to, or greater than the specified card.
	 */
	@Override
	public int compareTo(Card other) {
		int rankDiff = this.getValue() - other.getValue();
		if (rankDiff != 0) {
			return rankDiff;
		}
		return this.suit - other.suit;
	}

	/**
	 * Returns a string representation of this card's rank.
	 *
	 * @return a string representation of this card's rank
	 */
	public String toString() {
		return RANK_NAMES[rank - 1];
	}
}