
/**
 * 
 * This class is responsible for creating and managing the game logic and GUI of the Roulette game
 * 
 * It extends JPanel and implements ActionListener
 */

import java.awt.*;
import javax.swing.SwingUtilities;
import java.awt.event.*;
import javax.swing.*;

public class RouletteGame extends JPanel implements ActionListener {
	private static final int NUM_SPOTS = 37;
	private static final int[] VALUES = { 0, 32, 15, 19, 4, 21, 2, 25, 17, 34, 6, 27, 13, 36, 11, 30, 8, 23, 10, 5, 24,
			16, 33, 1, 20, 14, 31, 9, 22, 18, 29, 7, 28, 12, 35, 3, 26 };
	private static final String[] COLORS = { "green", "red", "black", "red", "black", "red", "black", "red", "black",
			"red", "black", "black", "red", "black", "red", "black", "red", "black", "red", "red", "black", "red",
			"black", "red", "black", "black", "red", "black", "red", "black", "red", "black", "red", "black", "red",
			"green" };

	private JButton[] numberButtons;
	private JButton redButton, greenButton, blackButton, oneTo18Button, evenButton, oddButton, button19To36;
	private JLabel ballSpotLabel, resultLabel, balanceLabel;
	private int ballSpot, betAmount, balance;
	private String betColor;
	private int betNumber = -1;
	private RouletteWheel rouletteWheel; // from RouletteWheel class

	/**
	 * Constructor for the Roulette class
	 * 
	 * @param balance the starting balance for the game
	 */
	public RouletteGame(int balance) {
		setLayout(new BorderLayout());
		this.balance = balance;
		rouletteWheel = new RouletteWheel();

		JPanel topPanel = new JPanel();
		topPanel.setLayout(new GridLayout(3, 13));
		numberButtons = new JButton[NUM_SPOTS];
		for (int i = 0; i < NUM_SPOTS - 1; i++) {
			numberButtons[i] = new JButton(Integer.toString(VALUES[i]));
			String color = COLORS[i];
			Color bg = color.equals("red") ? Color.RED : color.equals("black") ? Color.BLACK : Color.GREEN;
			Color fg = Color.WHITE;
			numberButtons[i].setBackground(bg);
			numberButtons[i].setForeground(fg);
			numberButtons[i].addActionListener(this);
			topPanel.add(numberButtons[i]);
		}

		JPanel bottomPanel = new JPanel();
		bottomPanel.setLayout(new GridLayout(2, 5));

		// Set background and font color for each button
		redButton = new JButton("Red");
		redButton.addActionListener(this);
		redButton.setBackground(Color.RED);
		redButton.setForeground(Color.WHITE);
		bottomPanel.add(redButton);

		blackButton = new JButton("Black");
		blackButton.addActionListener(this);
		blackButton.setBackground(Color.BLACK);
		blackButton.setForeground(Color.WHITE);
		bottomPanel.add(blackButton);

		greenButton = new JButton("Green");
		greenButton.addActionListener(this);
		greenButton.setBackground(Color.GREEN);
		greenButton.setForeground(Color.WHITE);
		bottomPanel.add(greenButton);

		oddButton = new JButton("Odd");
		oddButton.addActionListener(this);
		oddButton.setBackground(Color.RED);
		oddButton.setForeground(Color.WHITE);
		bottomPanel.add(oddButton);

		evenButton = new JButton("Even");
		evenButton.addActionListener(this);
		evenButton.setBackground(Color.BLACK);
		evenButton.setForeground(Color.WHITE);
		bottomPanel.add(evenButton);

		oneTo18Button = new JButton("1-18");
		oneTo18Button.addActionListener(this);
		bottomPanel.add(oneTo18Button);

		button19To36 = new JButton("19-36");
		button19To36.addActionListener(this);
		bottomPanel.add(button19To36);

		JPanel centerPanel = new JPanel();
		centerPanel.setLayout(new GridLayout(3, 1));

		ballSpotLabel = new JLabel("Ball has not been spun yet");
		ballSpotLabel.setHorizontalAlignment(JLabel.CENTER);
		centerPanel.add(ballSpotLabel);

		resultLabel = new JLabel("");
		resultLabel.setHorizontalAlignment(JLabel.CENTER);
		centerPanel.add(resultLabel);
		balanceLabel = new JLabel("Balance: " + balance);
		balanceLabel.setHorizontalAlignment(JLabel.CENTER);
		centerPanel.add(balanceLabel);

		add(topPanel, BorderLayout.NORTH);
		add(bottomPanel, BorderLayout.SOUTH);
		add(centerPanel, BorderLayout.CENTER);

	}

	/**
	 * Handles button clicks and updates the game state accordingly.
	 * 
	 * @param e the ActionEvent that triggered this method
	 */
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == redButton) {
			betColor = "red";
			betAmount = Integer.parseInt(JOptionPane.showInputDialog("Enter your bet amount:"));
		} else if (e.getSource() == blackButton) {
			betColor = "black";
			betAmount = Integer.parseInt(JOptionPane.showInputDialog("Enter your bet amount:"));
		} else if (e.getSource() == greenButton) {
			betColor = "green";
			betAmount = Integer.parseInt(JOptionPane.showInputDialog("Enter your bet amount:"));
		} else if (e.getSource() == oddButton) {
			betNumber = -2;
			betAmount = Integer.parseInt(JOptionPane.showInputDialog("Enter your bet amount:"));
		} else if (e.getSource() == evenButton) {
			betNumber = -3;
			betAmount = Integer.parseInt(JOptionPane.showInputDialog("Enter your bet amount:"));
		} else if (e.getSource() == oneTo18Button) {
			betNumber = -4;
			betAmount = Integer.parseInt(JOptionPane.showInputDialog("Enter your bet amount:"));
		} else if (e.getSource() == button19To36) {
			betNumber = -5;
			betAmount = Integer.parseInt(JOptionPane.showInputDialog("Enter your bet amount:"));
		} else {
			for (int i = 0; i < NUM_SPOTS; i++) {
				if (e.getSource() == numberButtons[i]) {
					betNumber = VALUES[i];
					betAmount = Integer.parseInt(JOptionPane.showInputDialog("Enter your bet amount:"));
				}
			}
		}

		// Spin the ball and update the labels
		spinBall();
	}

	/**
	 * Spins the roulette ball and updates the GUI to reflect the result of the spin
	 * Calculates and updates the balance of the player based on their bet and the
	 * result of the spin
	 */
	public void spinBall() {
		int spotIndex = (int) (Math.random() * rouletteWheel.getSize());
		int ballSpot = rouletteWheel.getValue(spotIndex);
		String color = rouletteWheel.getColor(spotIndex);

		// Update GUI to reflect ball spin
		ballSpotLabel.setText("Ball landed on " + ballSpot + " (" + color + ")");
		if (betNumber == ballSpot) {
			if (ballSpot == 0) {
				balance += betAmount * 35;
			} else {
				balance += betAmount * 36;
			}
			resultLabel.setText("You won $" + (betAmount * (ballSpot == 0 ? 35 : 36)));
		} else if (betColor != null && betColor.equals(color)) {
			balance += betAmount;
			resultLabel.setText("You won $" + betAmount);
		} else if (betNumber == -2 && ballSpot % 2 != 0) {
			balance += betAmount;
			resultLabel.setText("You won $" + betAmount);
		} else if (betNumber == -3 && ballSpot % 2 == 0) {
			balance += betAmount;
			resultLabel.setText("You won $" + betAmount);
		} else if (betNumber == -4 && ballSpot >= 1 && ballSpot <= 18) {
			balance += betAmount;
			resultLabel.setText("You won $" + betAmount);
		} else if (betNumber == -5 && ballSpot >= 19 && ballSpot <= 36) {
			balance += betAmount;
			resultLabel.setText("You won $" + betAmount);
		} else {
			balance -= betAmount;
			resultLabel.setText("You lost $" + betAmount);
		}

		balanceLabel.setText("Balance: $" + balance);
		betAmount = 0;
		betColor = null;
		betNumber = -1;
	}
}