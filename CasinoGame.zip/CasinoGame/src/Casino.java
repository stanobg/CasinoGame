/**
 * 
 * The Casino class is the main class to run our Casino game application
 * It contains the main method for starting the game and creating the main menu
 *
 */

public class Casino {
    public static void main(String[] args) {
        MainMenuGUI mainMenu = new MainMenuGUI();
    }
}
