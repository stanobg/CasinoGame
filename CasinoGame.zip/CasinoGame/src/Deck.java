/**
 * A class representing a standard deck of playing cards.
 * The deck contains 52 cards, consisting of 4 suits (hearts, diamonds, clubs, spades)
 * and 13 ranks (ace, 2, 3, 4, 5, 6, 7, 8, 9, 10, jack, queen, king).
 * Each card has a suit, rank, and an image.
 * The deck can be shuffled, reset, and individual cards can be drawn from the top of the deck.
*/

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Deck {
    private List<Card> cards;
    private int topCardIndex;
    private int cardsDealt;
    public static final String[] RANK_NAMES = { "ace", "2", "3", "4", "5", "6", "7", "8", "9", "10", "jack", "queen", "king" };
    public static final String[] SUIT_NAMES = { "hearts", "diamonds", "clubs", "spades" };
    
    /**
     * Constructor for Deck class.
     * Initializes the deck by creating 52 cards (13 ranks x 4 suits), 
     * adding them to the deck list, and shuffling the deck.
     * 
     * @param cardImages an array of image file names for each card in the deck
     */
    public Deck(String[] cardImages) {
        cards = new ArrayList<>();
        for (int suit = 0; suit < SUIT_NAMES.length; suit++) {
            for (int rank = 1; rank <= RANK_NAMES.length; rank++) {
                String image = cardImages[(suit * RANK_NAMES.length) + (rank - 1)];
                Card card = new Card(suit, rank);
                cards.add(card);
            }
        }
        topCardIndex = 0;
        cardsDealt = 0;
        Collections.shuffle(cards);
    }

    /**
     * Draws the top card from the deck, removing it from the deck list.
     * 
     * @return the Card object that was drawn, or null if there are no more cards in the deck
     */
    public Card drawCard() {
        if (topCardIndex >= cards.size()) {
            return null;
        }
        Card card = cards.get(topCardIndex);
        topCardIndex++;
        cardsDealt++;
        return card;
    }

    /**
     * Shuffles the deck by randomizing the order of cards in the deck list.
     * Resets the topCardIndex and cardsDealt counters to zero.
     */
    public void shuffle() {
        Collections.shuffle(cards);
        topCardIndex = 0;
        cardsDealt = 0;
    }
  
    /**
     * Resets the deck by setting the topCardIndex and cardsDealt counters to zero.
     */
    public void reset() {
        topCardIndex = 0;
        cardsDealt = 0;
    }

    /**
     * Returns the number of cards remaining in the deck.
     * 
     * @return the number of cards remaining in the deck
     */
    public int cardsRemaining() {
        return cards.size() - topCardIndex;
    }

    /**
     * Returns true if there are no more cards remaining in the deck, false otherwise.
     * 
     * @return true if there are no more cards remaining in the deck, false otherwise
     */
    public boolean isEmpty() {
        return cardsRemaining() == 0;
    }

    /**
     * Returns the number of cards that have been dealt from the deck
     * 
     * @return the number of cards that have been dealt
     */
    public int getCardsDealt() {
        return cardsDealt;
    }
}