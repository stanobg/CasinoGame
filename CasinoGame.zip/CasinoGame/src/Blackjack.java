
/**
 * This class is responsible for creating and managing the game logic and GUI of the blackjack game
 * 
 * It extends JPanel and implements ActionListener
 */

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Blackjack extends JPanel implements ActionListener {
	private Deck deck;
	private Hand playerHand;
	private Hand dealerHand;
	private int playerBalance;
	private int playerBet;

	// GUI elements
	private JFrame frame;
	private JLabel balanceLabel;
	private JLabel betLabel;
	private JLabel playerHandLabel;
	private JLabel dealerHandLabel;
	private JPanel playerCardsPanel;
	private JPanel dealerCardsPanel;
	private JTextField betField;
	private JButton hitButton;
	private JButton standButton;
	private JButton dealButton;
	private JLabel resultLabel;

	/**
	 * Constructs a new Blackjack object. Initializes the deck of cards, player's
	 * and dealer's hand, and the player's balance. Sets up the graphical user
	 * interface by creating the necessary elements, setting the layout and adding
	 * the elements to the frame.
	 */
	public Blackjack() {
		deck = new Deck(CardImages.CARD_IMAGES);

		playerHand = new Hand();
		dealerHand = new Hand();
		playerBalance = 1000;

		// Initialize GUI elements
		frame = new JFrame("Blackjack");
		balanceLabel = new JLabel("Your balance is: $" + playerBalance);
		betLabel = new JLabel("Enter your bet:");

		playerHandLabel = new JLabel("Your hand:");
		dealerHandLabel = new JLabel("Dealer's hand:");
		playerCardsPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
		dealerCardsPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));

		betField = new JTextField(5);
		hitButton = new JButton("Hit");
		hitButton.addActionListener(this);
		standButton = new JButton("Stand");
		standButton.addActionListener(this);
		dealButton = new JButton("Deal");
		dealButton.addActionListener(this);
		resultLabel = new JLabel("");

		// Set layout and add elements to frame
		frame.setLayout(new BorderLayout());
		JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
		topPanel.add(balanceLabel);
		topPanel.add(betLabel);
		topPanel.add(betField);
		topPanel.add(dealButton);
		frame.add(topPanel, BorderLayout.NORTH);

		JPanel centerPanel = new JPanel(new GridLayout(2, 1));
		JPanel playerPanel = new JPanel(new BorderLayout());
		playerPanel.add(playerHandLabel, BorderLayout.NORTH);
		playerPanel.add(playerCardsPanel, BorderLayout.CENTER);
		centerPanel.add(playerPanel);

		JPanel dealerPanel = new JPanel(new BorderLayout());
		dealerPanel.add(dealerHandLabel, BorderLayout.NORTH);
		dealerPanel.add(dealerCardsPanel, BorderLayout.CENTER);
		centerPanel.add(dealerPanel);

		frame.add(centerPanel, BorderLayout.CENTER);

		JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
		bottomPanel.add(hitButton);
		bottomPanel.add(standButton);
		bottomPanel.add(resultLabel);
		frame.add(bottomPanel, BorderLayout.SOUTH);

		// Set frame properties
		frame.setSize(800, 600);
		//frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.setVisible(true);
	}

	/**
	 * Implements the actionPerformed method of the ActionListener interface Handles
	 * the actions of the Hit, Stand and Deal buttons
	 * 
	 * @param e the ActionEvent object representing the action performed
	 */
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == hitButton) {
			// Draw a card and add it to the player's hand
			playerHand.addCard(deck.drawCard());
			playerCardsPanel.add(new JLabel(new ImageIcon(playerHand.getCards().get(playerHand.size() - 1).getImage()
					.getScaledInstance(100, 200, Image.SCALE_SMOOTH))));
			playerCardsPanel.revalidate();
			playerCardsPanel.repaint();

			// Check if the player busted
			if (playerHand.getBlackjackValue() > 21) {
				dealerHandLabel.setText(dealerHand.toString());
				resultLabel.setText("Busted. Dealer wins.");
				playerBalance -= playerBet;
				balanceLabel.setText("Balance: $" + playerBalance);
				checkGameOver();
			}
		} else if (e.getSource() == standButton) {
			// Dealer draws until their hand is at least 17
			while (dealerHand.getBlackjackValue() < 17) {
				dealerHand.addCard(deck.drawCard());
				dealerCardsPanel.add(new JLabel(new ImageIcon(dealerHand.getCards().get(dealerHand.size() - 1)
						.getImage().getScaledInstance(100, 200, Image.SCALE_SMOOTH))));
				dealerCardsPanel.revalidate();
				dealerCardsPanel.repaint();
			}

			// Check who won
			if (dealerHand.getBlackjackValue() > 21
					|| playerHand.getBlackjackValue() > dealerHand.getBlackjackValue()) {
				resultLabel.setText("You win!");
				playerBalance += playerBet;
				balanceLabel.setText("Balance: $" + playerBalance);
			} else if (dealerHand.getBlackjackValue() > playerHand.getBlackjackValue()) {
				resultLabel.setText("Dealer wins.");
				playerBalance -= playerBet;
				balanceLabel.setText("Balance: $" + playerBalance);
			} else {
				resultLabel.setText("Push.");
			}

			checkGameOver();
		} else if (e.getSource() == dealButton) {
			// Reset the game
			deck = new Deck(CardImages.CARD_IMAGES);
			deck.shuffle();

			playerHand.clear(); // Clear the player's hand
			dealerHand = new Hand();

			playerCardsPanel.removeAll(); // Remove all cards from player's hand panel
			dealerCardsPanel.removeAll(); // Remove all cards from dealer's hand panel

			// Reset the bet
			if (betField.getText().equals("")) {
				JOptionPane.showMessageDialog(frame, "Please enter a bet.");
			} else {
				playerBet = Integer.parseInt(betField.getText());

				if (playerBet > playerBalance) {
					JOptionPane.showMessageDialog(frame, "You do not have enough balance.");
				} else {
					playerHand.addCard(deck.drawCard());
					dealerHand.addCard(deck.drawCard());
					playerHand.addCard(deck.drawCard());

					playerCardsPanel.add(new JLabel(new ImageIcon(
							playerHand.getCards().get(0).getImage().getScaledInstance(100, 200, Image.SCALE_SMOOTH))));
					playerCardsPanel.add(new JLabel(new ImageIcon(
							playerHand.getCards().get(1).getImage().getScaledInstance(100, 200, Image.SCALE_SMOOTH))));
					dealerCardsPanel.add(new JLabel(new ImageIcon(
							dealerHand.getCards().get(0).getImage().getScaledInstance(100, 200, Image.SCALE_SMOOTH))));
					playerCardsPanel.revalidate();
					playerCardsPanel.repaint();
					dealerCardsPanel.revalidate();
					dealerCardsPanel.repaint();
					balanceLabel.setText("Balance: $" + playerBalance);
				}
			}
		}
	}

	/**
	 * 
	 * Checks if the player's balance is zero or negative, and ends the game if it is
	 * Displays a message to the user indicating that the game is over
	 * 
	 */
	private void checkGameOver() {
		if (playerBalance <= 0) {
			JOptionPane.showMessageDialog(frame, "You're out of money. Game over.");
			System.exit(0);
		}
	}
}
